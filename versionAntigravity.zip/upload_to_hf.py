"""
upload_to_hf.py — Subir capas ONNX de SmolLM2-1.7B a HuggingFace
=================================================================
Sube todos los archivos de onnx_layers_1.7b/ a tu repo de HuggingFace.

Requisito: pip install huggingface_hub
Ya debes estar logeado: huggingface-cli login
"""

from huggingface_hub import HfApi, create_repo
import os
import sys
import io

# Fix Windows console encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# ── Config ──────────────────────────────────────────────────────────
REPO_ID = "powerpudu/Web-Petals-SmolLM2-1.7B"
LOCAL_DIR = "onnx_layers_1.7b"
REPO_TYPE = "model"

print(f"═══════════════════════════════════════════════════════")
print(f"  UPLOAD a HuggingFace")
print(f"  Repo:   {REPO_ID}")
print(f"  Local:  {LOCAL_DIR}/")
print(f"═══════════════════════════════════════════════════════")

# Verificar que existen los archivos
if not os.path.exists(LOCAL_DIR):
    print(f"❌ Error: No existe el directorio '{LOCAL_DIR}/'")
    print(f"   Primero ejecuta: python slice_model_real.py")
    sys.exit(1)

files = [f for f in os.listdir(LOCAL_DIR) if f.endswith('.onnx')]
total_mb = sum(os.path.getsize(os.path.join(LOCAL_DIR, f)) for f in files) / 1024 / 1024

print(f"\nArchivos encontrados: {len(files)}")
print(f"Total: {total_mb:.1f} MB ({total_mb/1024:.2f} GB)")
print()

# Crear repo si no existe
api = HfApi()
try:
    create_repo(REPO_ID, repo_type=REPO_TYPE, exist_ok=True)
    print(f"✅ Repo '{REPO_ID}' listo")
except Exception as e:
    print(f"⚠️ Repo: {e}")

# Subir todos los archivos
print(f"\nSubiendo {len(files)} archivos ONNX...")
print(f"(Esto puede tomar varios minutos con ~3.6GB)")
print()

for idx, fname in enumerate(sorted(files)):
    fpath = os.path.join(LOCAL_DIR, fname)
    fsize = os.path.getsize(fpath) / 1024 / 1024
    print(f"  [{idx+1}/{len(files)}] {fname} ({fsize:.1f} MB)...", end=" ", flush=True)
    try:
        api.upload_file(
            path_or_fileobj=fpath,
            path_in_repo=fname,
            repo_id=REPO_ID,
            repo_type=REPO_TYPE,
        )
        print("✅")
    except Exception as e:
        print(f"❌ {e}")

# También crear un README
readme_content = f"""---
tags:
  - onnx
  - web-petals
  - distributed-inference
  - smollm2
license: apache-2.0
---

# Web-Petals SmolLM2-1.7B ONNX Layers

SmolLM2-1.7B-Instruct split into individual ONNX transformer layer files for **distributed P2P inference**.

## Files

| File | Description | Approx Size |
|------|-------------|-------------|
| `embeds.onnx` | Token embedding table | ~27 MB |
| `layer_0.onnx` ... `layer_23.onnx` | 24 transformer blocks | ~140 MB each |
| `lm_head.onnx` | Final LayerNorm + LM head | ~27 MB |

## Architecture

- **Hidden size**: 2048
- **Layers**: 24
- **Attention heads**: 32
- **FFN size**: 8192
- **Vocab size**: 49152
- **Total**: ~3.6 GB (FP32)

## Usage

These files are loaded by the [Web-Petals](https://chatsinserver.vercel.app) P2P distributed inference system.
Each device in the swarm loads 2-4 layers based on its available RAM.

Forward pass: `embeds → layer_0 → ... → layer_23 → lm_head`

## License

Apache 2.0 (same as SmolLM2)
"""

readme_path = os.path.join(LOCAL_DIR, "README.md")
with open(readme_path, 'w') as f:
    f.write(readme_content)

api.upload_file(
    path_or_fileobj=readme_path,
    path_in_repo="README.md",
    repo_id=REPO_ID,
    repo_type=REPO_TYPE,
)

print(f"\n═══════════════════════════════════════════════════════")
print(f"  ✅ UPLOAD COMPLETO")
print(f"  URL: https://huggingface.co/{REPO_ID}")
print(f"  CDN: https://huggingface.co/{REPO_ID}/resolve/main/")
print(f"═══════════════════════════════════════════════════════")
