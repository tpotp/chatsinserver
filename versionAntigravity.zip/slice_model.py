import torch
from transformers import AutoModelForCausalLM
import transformers.models.llama.modeling_llama as ml

def patch_rotary(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (ml.rotate_half(q) * sin)
    k_embed = (k * cos) + (ml.rotate_half(k) * sin)
    return q_embed, k_embed

ml.apply_rotary_pos_emb = patch_rotary

model_id = "HuggingFaceTB/SmolLM2-135M"
print(f"Cargando modelo maestro con Machete RoPE: {model_id}...")
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.float32, attn_implementation="eager")
model.config.torch_dtype = torch.float32
model.config.use_bfloat16 = False
model.float()
model.eval()

import os
os.makedirs("onnx_layers", exist_ok=True)

class EmbedWrap(torch.nn.Module):
    def __init__(self, m):
        super().__init__()
        self.embed_tokens = m.model.embed_tokens
    def forward(self, input_ids):
        return self.embed_tokens(input_ids).to(torch.float32)

class LayerWrap(torch.nn.Module):
    def __init__(self, layer, rotary_emb):
        super().__init__()
        self.layer = layer
        self.rotary = rotary_emb
    def forward(self, hidden_states, attention_mask, position_ids):
        position_embeddings = self.rotary(hidden_states, position_ids)
        return self.layer(hidden_states, attention_mask=attention_mask, position_embeddings=position_embeddings, use_cache=False)[0].to(torch.float32)

print("Iniciando Slicing Full de todas las Capas...")

b_size, seq_len = 1, 3
hidden_dim = model.config.hidden_size

input_ids = torch.randint(0, 1000, (b_size, seq_len))
embeder = EmbedWrap(model)

print(" -> Exportando Embeddings...")
torch.onnx.export(
    embeder, (input_ids,), "onnx_layers/embeds.onnx",
    input_names=["input_ids"], output_names=["hidden_states"],
    dynamic_axes={"input_ids": {1: "seq"}, "hidden_states": {1: "seq"}},
    opset_version=14, do_constant_folding=True
)

hidden_states = torch.randn((b_size, seq_len, hidden_dim), dtype=torch.float32)
attention_mask = torch.ones((b_size, 1, seq_len, seq_len), dtype=torch.float32)
position_ids = torch.arange(0, seq_len, dtype=torch.long).unsqueeze(0)

print(f"Detectadas {len(model.model.layers)} capas. Comenzando exportacion secuencial.")

for i, layer in enumerate(model.model.layers):
    print(f" -> Exportando Capa Logica {i}...")
    layer_model = LayerWrap(layer, model.model.rotary_emb)
    torch.onnx.export(
        layer_model, (hidden_states, attention_mask, position_ids), f"onnx_layers/layer_{i}.onnx",
        input_names=["input_hidden", "attention_mask", "position_ids"], output_names=["output_hidden"],
        dynamic_axes={"input_hidden": {1: "seq"}, "attention_mask": {2: "seq", 3: "seq"}, "position_ids": {1: "seq"}, "output_hidden": {1: "seq"}},
        opset_version=14, do_constant_folding=True
    )

class HeadWrap(torch.nn.Module):
    def __init__(self, m):
        super().__init__()
        self.norm = m.model.norm
        self.lm_head = m.lm_head
    def forward(self, hidden_states):
        return self.lm_head(self.norm(hidden_states))[:, -1, :]

head = HeadWrap(model)
print(" -> Exportando LM Head...")
torch.onnx.export(
    head, (hidden_states,), "onnx_layers/lm_head.onnx",
    input_names=["hidden_states"], output_names=["logits"],
    dynamic_axes={"hidden_states": {1: "seq"}}, opset_version=14, do_constant_folding=True
)

print("Exito! Modelo completo dividido matematicamente en ONNX.")
