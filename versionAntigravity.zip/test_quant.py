﻿from onnxruntime.quantization import quantize_dynamic, QuantType
import os

in_path = "onnx_layers_1.7b/layer_0.onnx"
out_path = "onnx_layers_1.7b/layer_0_int8.onnx"
print("Quantizing", in_path)
quantize_dynamic(in_path, out_path, weight_type=QuantType.QInt8)
size_mb = os.path.getsize(out_path) / 1024 / 1024
print(f"Done! Size: {size_mb:.1f} MB")
