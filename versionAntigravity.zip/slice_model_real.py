"""
slice_model_real.py — Slicer REAL de SmolLM2-1.7B-Instruct a ONNX por capas
=============================================================================
Genera 26 archivos ONNX individuales:
  - embeds.onnx        (embedding table)
  - layer_0..23.onnx   (24 transformer blocks)
  - lm_head.onnx       (final norm + linear head)

Cada capa pesa ~140MB en FP32.
Total: ~3.6GB — NO cabe en un celular, pero sí repartido entre 10.

Requiere: pip install torch transformers
Corre en CPU (o GPU si hay). Tu RTX 4070 Ti lo exporta en minutos.
"""

import torch
from transformers import AutoModelForCausalLM, AutoConfig
import os
import sys
import io

# Fix Windows console encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# ── Patch RoPE para compatibilidad de ONNX export ──────────────────
import transformers.models.llama.modeling_llama as ml

def patch_rotary(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (ml.rotate_half(q) * sin)
    k_embed = (k * cos) + (ml.rotate_half(k) * sin)
    return q_embed, k_embed

ml.apply_rotary_pos_emb = patch_rotary

# ── Config ──────────────────────────────────────────────────────────
MODEL_ID = "HuggingFaceTB/SmolLM2-1.7B-Instruct"
OUTPUT_DIR = "onnx_layers_1.7b"
BATCH_SIZE = 1
SEQ_LEN = 4  # short seq for tracing, dynamic axes handle variable length

print(f"═══════════════════════════════════════════════════════")
print(f"  SLICER REAL — SmolLM2-1.7B-Instruct → ONNX")
print(f"  Modelo: {MODEL_ID}")
print(f"  Output: {OUTPUT_DIR}/")
print(f"═══════════════════════════════════════════════════════")

# ── Descargar y cargar modelo ───────────────────────────────────────
print(f"\n[1/4] Descargando modelo {MODEL_ID}...")
print(f"       (Primera vez descarga ~3.4GB, después usa cache)")

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.float32,
    attn_implementation="eager",  # ONNX no soporta flash/sdpa
    low_cpu_mem_usage=True,
)
model.config.torch_dtype = torch.float32
model.config.use_bfloat16 = False
model.float()
model.eval()

config = model.config
hidden_size = config.hidden_size
num_layers = config.num_hidden_layers
vocab_size = config.vocab_size

print(f"       ✅ Modelo cargado:")
print(f"          Hidden size:  {hidden_size}")
print(f"          Num layers:   {num_layers}")
print(f"          Vocab size:   {vocab_size}")
print(f"          Params:       {sum(p.numel() for p in model.parameters()) / 1e6:.0f}M")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Wrapper: Embeddings ─────────────────────────────────────────────
class EmbedWrap(torch.nn.Module):
    def __init__(self, m):
        super().__init__()
        self.embed_tokens = m.model.embed_tokens
    def forward(self, input_ids):
        return self.embed_tokens(input_ids).to(torch.float32)

# ── Wrapper: Transformer Layer ──────────────────────────────────────
class LayerWrap(torch.nn.Module):
    def __init__(self, layer, rotary_emb):
        super().__init__()
        self.layer = layer
        self.rotary = rotary_emb
    def forward(self, hidden_states, attention_mask, position_ids):
        position_embeddings = self.rotary(hidden_states, position_ids)
        out = self.layer(
            hidden_states,
            attention_mask=attention_mask,
            position_embeddings=position_embeddings,
            use_cache=False
        )[0]
        return out.to(torch.float32)

# ── Wrapper: LM Head ───────────────────────────────────────────────
class HeadWrap(torch.nn.Module):
    def __init__(self, m):
        super().__init__()
        self.norm = m.model.norm
        self.lm_head = m.lm_head
    def forward(self, hidden_states):
        normed = self.norm(hidden_states)
        logits = self.lm_head(normed)
        # Solo último token (autoregressive)
        return logits[:, -1, :]

# ── Exportación ─────────────────────────────────────────────────────
print(f"\n[2/4] Exportando Embeddings...")

input_ids = torch.randint(0, 1000, (BATCH_SIZE, SEQ_LEN))
embeder = EmbedWrap(model)

embed_path = os.path.join(OUTPUT_DIR, "embeds.onnx")
torch.onnx.export(
    embeder, (input_ids,), embed_path,
    input_names=["input_ids"], output_names=["hidden_states"],
    dynamic_axes={"input_ids": {1: "seq"}, "hidden_states": {1: "seq"}},
    opset_version=14, do_constant_folding=True
)
embed_size = os.path.getsize(embed_path) / 1024 / 1024
print(f"       ✅ embeds.onnx ({embed_size:.1f} MB)")

# ── Exportar cada capa ──────────────────────────────────────────────
print(f"\n[3/4] Exportando {num_layers} Transformer Layers...")

hidden_states = torch.randn((BATCH_SIZE, SEQ_LEN, hidden_size), dtype=torch.float32)
attention_mask = torch.ones((BATCH_SIZE, 1, SEQ_LEN, SEQ_LEN), dtype=torch.float32)
position_ids = torch.arange(0, SEQ_LEN, dtype=torch.long).unsqueeze(0)

total_layer_mb = 0
for i, layer in enumerate(model.model.layers):
    layer_path = os.path.join(OUTPUT_DIR, f"layer_{i}.onnx")
    layer_model = LayerWrap(layer, model.model.rotary_emb)
    
    torch.onnx.export(
        layer_model, (hidden_states, attention_mask, position_ids),
        layer_path,
        input_names=["input_hidden", "attention_mask", "position_ids"],
        output_names=["output_hidden"],
        dynamic_axes={
            "input_hidden": {1: "seq"},
            "attention_mask": {2: "seq", 3: "seq"},
            "position_ids": {1: "seq"},
            "output_hidden": {1: "seq"}
        },
        opset_version=14, do_constant_folding=True
    )
    layer_size = os.path.getsize(layer_path) / 1024 / 1024
    total_layer_mb += layer_size
    print(f"       ✅ layer_{i}.onnx ({layer_size:.1f} MB)  [{i+1}/{num_layers}]")

# ── Exportar LM Head ───────────────────────────────────────────────
print(f"\n[4/4] Exportando LM Head (norm + linear)...")

head = HeadWrap(model)
head_path = os.path.join(OUTPUT_DIR, "lm_head.onnx")
torch.onnx.export(
    head, (hidden_states,), head_path,
    input_names=["hidden_states"], output_names=["logits"],
    dynamic_axes={"hidden_states": {1: "seq"}},
    opset_version=14, do_constant_folding=True
)
head_size = os.path.getsize(head_path) / 1024 / 1024
print(f"       ✅ lm_head.onnx ({head_size:.1f} MB)")

# ── Resumen ─────────────────────────────────────────────────────────
total_mb = embed_size + total_layer_mb + head_size
total_files = 2 + num_layers  # embeds + layers + head

print(f"\n═══════════════════════════════════════════════════════")
print(f"  ✅ SLICING COMPLETO")
print(f"     Archivos:    {total_files}")
print(f"     Embeds:      {embed_size:.1f} MB")
print(f"     Capas:       {total_layer_mb:.1f} MB ({num_layers} × {total_layer_mb/num_layers:.1f} MB avg)")
print(f"     LM Head:     {head_size:.1f} MB")
print(f"     TOTAL:       {total_mb:.1f} MB ({total_mb/1024:.2f} GB)")
print(f"")
print(f"  📱 Distribución sugerida para 10 celulares:")
for phone_idx in range(10):
    start = phone_idx * (num_layers // 10)
    end = (phone_idx + 1) * (num_layers // 10) if phone_idx < 9 else num_layers
    components = []
    if phone_idx == 0:
        components.append("embeds")
    for l in range(start, end):
        components.append(f"layer_{l}")
    if phone_idx == 9:
        components.append("head")
    phone_mb = sum(
        os.path.getsize(os.path.join(OUTPUT_DIR, f"{'lm_head' if c == 'head' else c}.onnx")) / 1024 / 1024
        for c in components
    )
    print(f"     Celular {phone_idx+1}: {components[0]}...{components[-1]} ({phone_mb:.0f} MB)")
print(f"═══════════════════════════════════════════════════════")
